import * as React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { createStackNavigator } from '@react-navigation/stack';
import HomeScreen from './screens/HomeScreen';
import ProfileScreen from './screens/ProfileScreen';
import Bejelentkezes from './screens/Bejelentkezes';
import Regisztralas from './screens/Regisztralas';
import Fomenu from './screens/Fomenu';

const Drawer = createDrawerNavigator();
const Stack = createStackNavigator();



export default function App() {
  return (
    
      <NavigationContainer>
        <Stack.Navigator >
          <Stack.Screen name="HomeScreen" component={HomeScreen} options={{ title: 'Home',headerShown: false }} />
          <Stack.Screen name="Bejelentkezes" component={Bejelentkezes} />
          <Stack.Screen name="Regisztralas" component={Regisztralas} />
          <Stack.Screen name="Fomenu" component={Fomenu} />
        </Stack.Navigator>
      </NavigationContainer>
  );
}

