import React, { useState } from 'react';
import { View, TextInput, Button, Text, StyleSheet,TouchableOpacity } from 'react-native';

const Regisztralas = () => {
  // Állapotok a form mezőihez és hibákhoz
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errors, setErrors] = useState({
    name: '',
    email: '',
    password: ''
  });

  // A regisztráció kezelése
  const handleRegister = () => {
    let valid = true;
    let newErrors = {
      name: '',
      email: '',
      password: ''
    };

    // Hibák ellenőrzése
    if (!name) {
      newErrors.name = 'A név megadása kötelező';
      valid = false;
    }
    if (!email) {
      newErrors.email = 'Az e-mail megadása kötelező';
      valid = false;
    } else if (!/\S+@\S+\.\S+/.test(email)) {
      newErrors.email = 'Érvénytelen e-mail cím';
      valid = false;
    }
    if (!password) {
      newErrors.password = 'A jelszó megadása kötelező';
      valid = false;
    }

    setErrors(newErrors);

    // Ha minden mező helyes, regisztrálás
    if (valid) {
      alert('Sikeres regisztráció');
      // Itt hívhatod meg a regisztrációs API-t vagy további műveleteket végezhetsz
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Regisztráció</Text>
      
      <TextInput
        style={styles.input}
        placeholder="Név"
        value={name}
        onChangeText={setName}
      />
      {errors.name ? <Text style={styles.error}>{errors.name}</Text> : null}

      <TextInput
        style={styles.input}
        placeholder="E-mail"
        keyboardType="email-address"
        value={email}
        onChangeText={setEmail}
      />
      {errors.email ? <Text style={styles.error}>{errors.email}</Text> : null}

      <TextInput
        style={styles.input}
        placeholder="Jelszó"
        secureTextEntry
        value={password}
        onChangeText={setPassword}
      />
      {errors.password ? <Text style={styles.error}>{errors.password}</Text> : null}

      <TouchableOpacity style={styles.button} onPress={handleRegister}>
                <Text style={styles.buttonText}>Regisztrálok</Text>
            </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  header: {
    fontSize: 24,
        fontWeight: 'bold',
        marginBottom: 10,
  },
  input: {
    width: '100%',
    padding: 10,
    marginVertical: 10,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
  },
  error: {
    color: 'red',
    fontSize: 12,
  },
  button: {
    backgroundColor: '#4CAF50',
    padding: 15,
    borderRadius: 5,
    width: '100%',
    alignItems: 'center',
},
buttonText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
}
});

export default Regisztralas;
