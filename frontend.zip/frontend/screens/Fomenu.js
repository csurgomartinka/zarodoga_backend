import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Button } from 'react-native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createStackNavigator } from '@react-navigation/stack';
import { NavigationContainer } from '@react-navigation/native';
import { MaterialCommunityIcons } from '@expo/vector-icons';

// Események adatainak definiálása
const events = [
    {
        id: '1',
        title: 'Budapesti Zenei Fesztivál',
        date: '2024. December 15.',
        location: 'Budapest, Papp László Sportaréna',
        image: 'https://via.placeholder.com/400x200',
    },
    {
        id: '2',
        title: 'Boryi Borfesztivál',
        date: '2024. November 30.',
        location: 'Pécs, Bory-vár',
        image: 'https://via.placeholder.com/400x200',
    },
    {
        id: '3',
        title: 'Téli Művészeti Kiállítás',
        date: '2024. December 5.',
        location: 'Veszprém, Művészetek Háza',
        image: 'https://via.placeholder.com/400x200',
    },
];

// Főoldal képernyő
function HomeScreen({ navigation }) {
    return (
        <View style={styles.container}>
            <Text style={styles.header}>Magyarország Eseményei</Text>
            <Text>Mi egy dinamikus és lelkes csapat vagyunk, akik elkötelezettek amellett, hogy a legjobb élményeket és információkat nyújtsuk Magyarország eseményeiről. A célunk, hogy a felhasználók könnyedén hozzáférhessenek a legfrissebb rendezvényekhez, fesztiválokhoz, koncertekhez és kulturális eseményekhez, mind weboldalon, mind mobil applikációban.Weboldalunk és telefonos applikációnk segítségével bármikor és bárhonnan tájékozódhatsz a legfontosabb eseményekről, amelyeket nem érdemes kihagyni! Az applikációnk és az oldalunk naprakész, könnyen navigálható, és biztosítja, hogy soha ne maradj le a legizgalmasabb programokról</Text>
            <View style={[styles.container4,
            {
                // Try setting `flexDirection` to `"row"`.
                flexDirection: 'column',
            },
            ]}>
                <View style={{ flex: 1, backgroundColor: 'red' }} />
                <View style={{ flex: 2, backgroundColor: 'darkorange' }} />
                <View style={{ flex: 3, backgroundColor: 'green' }} />
            </View>

        </View>

    );
}

// Kapcsolat képernyő
function ContactScreen({ navigation }) {
    return (
        <View style={styles.container1}>
            <Text style={styles.header}>Vedd fel  velünk a kapcsolatot!</Text>
            <Text style={styles.text}>Email: info@esemenyek.hu</Text>
            <Text style={styles.text}>Telefon: +36 30 123 4567</Text>
            <Text style={styles.text}>Cím: Budapest, Fő utca 1.</Text>
            <TouchableOpacity
                style={styles.button}
                onPress={() => navigation.navigate('Főoldal')}
            >
                <Text style={styles.buttonText}>Vissza a Főoldalra</Text>
            </TouchableOpacity>
        </View>
    );
}

// Események képernyő
function EsemenyScreen({ navigation }) {
    return (
        <View style={styles.container1}>
            <Text style={styles.header}>Magyarország Eseményei</Text>

            {events.map((event) => (
                <View key={event.id} style={styles.eventCard}>
                    <Text style={styles.eventTitle}>{event.title}</Text>
                    <Text style={styles.eventDate}>{event.date}</Text>
                    <Text style={styles.eventLocation}>{event.location}</Text>
                </View>
            ))}
        </View>
    );
}


// Navigáció a fülökhöz
const Tab = createBottomTabNavigator();
const Stack = createStackNavigator();

// A fő navigációs képernyő
function FomenuTabs() {
    return (
        <Tab.Navigator>
            <Tab.Screen
                name="Főoldal"
                component={HomeScreen}
                options={{
                    tabBarIcon: ({ color }) => (
                        <MaterialCommunityIcons name="home" size={24} color={color} />
                    ),

                }}
            />
            <Tab.Screen
                name="Esemenyek"
                component={EsemenyScreen}
                options={{
                    tabBarIcon: ({ color }) => (
                        <MaterialCommunityIcons name="email" size={24} color={color} />
                    ),
                }}
            />
            <Tab.Screen
                name="Kapcsolat"
                component={ContactScreen}
                options={{
                    tabBarIcon: ({ color }) => (
                        <MaterialCommunityIcons name="email" size={24} color={color} />
                    ),
                }}
            />

        </Tab.Navigator>
    );
}

// Stack Navigator, hogy kezeljük az összes képernyőt
export default function Fomenu() {
    return (
        <Stack.Navigator>
            <Stack.Screen
                name="Főoldal és Kapcsolat"
                component={FomenuTabs}
                options={{ headerShown: false }}
            />
        </Stack.Navigator>
    );
}

// Stílusok
const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#d4edda', // Világoszöld háttérszín
        padding: 20,
        alignItems: 'center',
    },
    container1: {
        flex: 1,
        backgroundColor: '#d4edda', // Világoszöld háttérszín
        padding: 20,
    },
    container4: {
        flex: 1,
        padding: 20,
    },
    header: {
        fontSize: 24,
        fontWeight: 'bold',
        color: '#6200ea',
        marginBottom: 20,
        textAlign: 'center',
    },
    text: {
        fontSize: 18,
        color: '#333',
        marginBottom: 10,
    },
    button: {
        backgroundColor: '#6200ea',
        padding: 10,
        borderRadius: 5,
        marginTop: 20,
        alignItems: 'center',
    },
    buttonText: {
        color: '#fff',
        fontSize: 18,
    },
    eventCard: {
        backgroundColor: '#fff',
        padding: 15,
        marginVertical: 10,
        borderRadius: 10,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 5,
        elevation: 5,
    },
    eventTitle: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#333',
    },
    eventDate: {
        fontSize: 14,
        color: '#6200ea',
        marginTop: 5,
    },
    eventLocation: {
        fontSize: 14,
        color: '#777',
        marginTop: 5,
    },
});

